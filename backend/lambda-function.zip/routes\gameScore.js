"use strict";
// POST /game/score - Records final score and updates ranking
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameScore = handleGameScore;
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
async function handleGameScore(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    // Validate body
    let body;
    try {
        body = JSON.parse(event.body || '{}');
    }
    catch {
        return (0, response_1.buildErrorResponse)(400, 'Pontuação inválida', origin);
    }
    const score = body.score;
    if (typeof score !== 'number' || !Number.isInteger(score) || score < 0 || score >= 1000000) {
        return (0, response_1.buildErrorResponse)(400, 'Pontuação inválida', origin);
    }
    try {
        // Check active session
        const session = await cacheService_1.cacheService.getGameSession(sub);
        if (!session || session.status !== 'playing') {
            return (0, response_1.buildErrorResponse)(409, 'Nenhuma sessão de jogo ativa', origin);
        }
        // Update ranking (ZADD GT - only updates if score is higher)
        const result = await cacheService_1.cacheService.updateRanking(sub, score);
        // End session
        await cacheService_1.cacheService.endGameSession(sub, score);
        return (0, response_1.buildResponse)(200, {
            recorded: true,
            newBest: result.newBest,
            bestScore: result.bestScore,
            rankPosition: result.rankPosition,
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço do jogo temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=gameScore.js.map