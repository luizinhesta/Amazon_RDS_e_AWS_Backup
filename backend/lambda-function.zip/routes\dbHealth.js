"use strict";
// GET /db/health - Verifica conectividade com RDS e réplica
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleDbHealth = handleDbHealth;
const databaseService_1 = require("../services/databaseService");
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
async function handleDbHealth(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const [writeOk, readOk, cacheOk] = await Promise.all([
        databaseService_1.databaseService.pingWrite(),
        databaseService_1.databaseService.pingRead(),
        cacheService_1.cacheService.ping(),
    ]);
    return (0, response_1.buildResponse)(200, {
        services: {
            rds_primary: writeOk ? 'connected' : 'disconnected',
            rds_replica: readOk ? 'connected' : 'disconnected',
            elasticache: cacheOk ? 'connected' : 'disconnected',
        },
        overall: writeOk && readOk && cacheOk ? 'healthy' : 'degraded',
        timestamp: new Date().toISOString(),
    }, origin);
}
//# sourceMappingURL=dbHealth.js.map