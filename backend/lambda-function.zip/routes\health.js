"use strict";
// GET /health - Public health check endpoint
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleHealth = handleHealth;
const response_1 = require("../utils/response");
function handleHealth(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    return (0, response_1.buildResponse)(200, {
        status: 'ok',
        message: 'API funcionando corretamente',
    }, origin);
}
//# sourceMappingURL=health.js.map