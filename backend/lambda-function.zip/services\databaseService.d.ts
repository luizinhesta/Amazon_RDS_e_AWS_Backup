export interface PlayerProfile {
    player_id: string;
    username: string;
    email: string;
    best_score: number;
    total_games: number;
    total_wins: number;
    total_losses: number;
    created_at: string;
    updated_at: string;
}
export interface GameMatch {
    match_id: string;
    player_id: string;
    score: number;
    duration_seconds: number;
    started_at: string;
    finished_at: string;
    is_new_record: boolean;
}
export interface RankingRecord {
    position: number;
    username: string;
    best_score: number;
    total_games: number;
}
export interface PlayerStats {
    player_id: string;
    username: string;
    best_score: number;
    total_games: number;
    total_wins: number;
    total_losses: number;
    average_score: number;
    total_play_time_seconds: number;
    last_played_at: string | null;
}
export declare const databaseService: {
    /**
     * Registra ou atualiza perfil do jogador no banco permanente
     */
    upsertPlayer(playerId: string, username: string, email: string): Promise<PlayerProfile>;
    /**
     * Registra uma partida finalizada
     */
    recordMatch(playerId: string, score: number, durationSeconds: number, isNewRecord: boolean): Promise<GameMatch>;
    /**
     * Atualiza estatísticas do jogador após partida
     */
    updatePlayerStats(playerId: string, score: number, isNewRecord: boolean): Promise<void>;
    /**
     * Consulta ranking consolidado (réplica de leitura)
     * Aceita pequena defasagem - ideal para relatórios
     */
    getRankingFromReplica(limit?: number): Promise<RankingRecord[]>;
    /**
     * Consulta histórico de partidas do jogador (réplica de leitura)
     */
    getPlayerHistory(playerId: string, limit?: number): Promise<GameMatch[]>;
    /**
     * Consulta estatísticas detalhadas do jogador (réplica de leitura)
     */
    getPlayerStats(playerId: string): Promise<PlayerStats | null>;
    /**
     * Verifica conectividade com o banco (escrita)
     */
    pingWrite(): Promise<boolean>;
    /**
     * Verifica conectividade com a réplica (leitura)
     */
    pingRead(): Promise<boolean>;
};
//# sourceMappingURL=databaseService.d.ts.map