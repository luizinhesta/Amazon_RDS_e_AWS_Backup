import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleHealth(event: APIGatewayProxyEvent): LambdaResponse;
//# sourceMappingURL=health.d.ts.map