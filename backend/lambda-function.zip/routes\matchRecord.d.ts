import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleMatchRecord(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=matchRecord.d.ts.map