import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handlePlayerStats(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=playerStats.d.ts.map