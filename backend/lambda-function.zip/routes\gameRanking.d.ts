import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleGameRanking(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=gameRanking.d.ts.map