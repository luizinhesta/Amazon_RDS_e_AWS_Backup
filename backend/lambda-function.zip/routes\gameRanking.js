"use strict";
// GET /game/ranking - Returns top 10 players ranking
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameRanking = handleGameRanking;
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
async function handleGameRanking(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    try {
        const ranking = await cacheService_1.cacheService.getTopRanking(10);
        return (0, response_1.buildResponse)(200, ranking, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço do jogo temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=gameRanking.js.map