"use strict";
// GET /player/history - Retorna histórico de partidas (via réplica de leitura)
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePlayerHistory = handlePlayerHistory;
const databaseService_1 = require("../services/databaseService");
const response_1 = require("../utils/response");
async function handlePlayerHistory(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    try {
        const limit = parseInt(event.queryStringParameters?.limit || '20', 10);
        const safeLimit = Math.min(Math.max(limit, 1), 50);
        const history = await databaseService_1.databaseService.getPlayerHistory(sub, safeLimit);
        return (0, response_1.buildResponse)(200, {
            matches: history,
            total: history.length,
            source: 'replica',
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço de banco de dados temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=playerHistory.js.map