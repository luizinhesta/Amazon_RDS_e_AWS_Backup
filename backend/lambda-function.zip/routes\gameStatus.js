"use strict";
// GET /game/status - Verifica conectividade real com o cache
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameStatus = handleGameStatus;
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
async function handleGameStatus(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    try {
        const isConnected = await cacheService_1.cacheService.ping();
        return (0, response_1.buildResponse)(200, {
            game: isConnected ? 'online' : 'offline',
            cache: isConnected ? 'connected' : 'disconnected',
        }, origin);
    }
    catch {
        return (0, response_1.buildResponse)(200, {
            game: 'offline',
            cache: 'disconnected',
        }, origin);
    }
}
//# sourceMappingURL=gameStatus.js.map