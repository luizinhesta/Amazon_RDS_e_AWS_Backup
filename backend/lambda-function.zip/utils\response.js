"use strict";
// Response helper - builds Lambda Proxy integration responses
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildResponse = buildResponse;
exports.buildErrorResponse = buildErrorResponse;
const cors_1 = require("./cors");
function buildResponse(statusCode, body, origin) {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            ...(0, cors_1.getCorsHeaders)(origin),
        },
        body: JSON.stringify(body),
    };
}
function buildErrorResponse(statusCode, message, origin) {
    return buildResponse(statusCode, { message }, origin);
}
//# sourceMappingURL=response.js.map