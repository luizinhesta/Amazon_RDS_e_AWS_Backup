/**
 * Masks sensitive data showing at most the last 4 characters.
 * - If value length <= 4: returns all asterisks (same length)
 * - If value length > 4: replaces first (length - 4) characters with asterisks, shows last 4 as-is
 */
export declare function maskSensitiveData(value: string): string;
/**
 * Logs a message to console.log with sanitized context.
 * String values in context whose keys contain 'token', 'password', 'secret', or 'authorization'
 * are masked to show at most the last 4 characters.
 */
export declare function logSafe(message: string, context?: Record<string, unknown>): void;
/**
 * Logs a message to console.error with sanitized context.
 * Same masking rules as logSafe.
 */
export declare function logError(message: string, context?: Record<string, unknown>): void;
//# sourceMappingURL=logger.d.ts.map