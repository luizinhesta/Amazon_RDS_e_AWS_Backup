import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleDbHealth(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=dbHealth.d.ts.map