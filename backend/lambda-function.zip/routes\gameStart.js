"use strict";
// POST /game/start - Creates a new game session in cache
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameStart = handleGameStart;
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
const GAME_SESSION_TTL = parseInt(process.env.GAME_SESSION_TTL || '1800', 10);
async function handleGameStart(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    const username = event.requestContext?.authorizer?.claims?.preferred_username ||
        event.requestContext?.authorizer?.claims?.name || 'Jogador';
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    try {
        const session = await cacheService_1.cacheService.createGameSession(sub);
        await cacheService_1.cacheService.setPlayerUsername(sub, username);
        return (0, response_1.buildResponse)(200, {
            sessionId: sub,
            status: session.status,
            expiresIn: GAME_SESSION_TTL,
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço do jogo temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=gameStart.js.map