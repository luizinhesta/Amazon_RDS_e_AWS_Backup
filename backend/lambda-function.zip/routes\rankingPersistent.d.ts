import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleRankingPersistent(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=rankingPersistent.d.ts.map