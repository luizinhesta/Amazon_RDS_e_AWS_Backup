"use strict";
// Database Service - Amazon RDS (PostgreSQL) via RDS Proxy
// Separação de leitura/escrita: principal para escrita, réplica para leitura
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseService = void 0;
const logger_1 = require("../utils/logger");
// Endpoints configuráveis por variáveis de ambiente
const RDS_PROXY_ENDPOINT = process.env.RDS_PROXY_ENDPOINT || 'localhost';
const RDS_REPLICA_ENDPOINT = process.env.RDS_REPLICA_ENDPOINT || RDS_PROXY_ENDPOINT;
const RDS_PORT = parseInt(process.env.RDS_PORT || '5432', 10);
const RDS_DATABASE = process.env.RDS_DATABASE || 'dinogame';
const RDS_USER = process.env.RDS_USER || 'dinogame_app';
// Senha obtida do Secrets Manager - NUNCA no código
const RDS_PASSWORD = process.env.RDS_PASSWORD || '';
function getWriteConfig() {
    return {
        host: RDS_PROXY_ENDPOINT,
        port: RDS_PORT,
        database: RDS_DATABASE,
        user: RDS_USER,
        password: RDS_PASSWORD,
        ssl: true,
    };
}
function getReadConfig() {
    return {
        host: RDS_REPLICA_ENDPOINT,
        port: RDS_PORT,
        database: RDS_DATABASE,
        user: RDS_USER,
        password: RDS_PASSWORD,
        ssl: true,
    };
}
// ============================================
// Database Service - Operações CRUD
// ============================================
exports.databaseService = {
    // ---- ESCRITA (via RDS Proxy → Instância Principal) ----
    /**
     * Registra ou atualiza perfil do jogador no banco permanente
     */
    async upsertPlayer(playerId, username, email) {
        const config = getWriteConfig();
        (0, logger_1.logSafe)('DB Write: upsertPlayer', { host: config.host, playerId });
        // Em produção: INSERT ... ON CONFLICT (player_id) DO UPDATE
        // Retorna o perfil atualizado
        const query = `
      INSERT INTO players (player_id, username, email, created_at, updated_at)
      VALUES ($1, $2, $3, NOW(), NOW())
      ON CONFLICT (player_id) DO UPDATE SET
        username = EXCLUDED.username,
        updated_at = NOW()
      RETURNING *;
    `;
        try {
            const result = await executeWrite(query, [playerId, username, email]);
            return result.rows[0];
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: upsertPlayer', { playerId, error: error.message });
            throw error;
        }
    },
    /**
     * Registra uma partida finalizada
     */
    async recordMatch(playerId, score, durationSeconds, isNewRecord) {
        const config = getWriteConfig();
        (0, logger_1.logSafe)('DB Write: recordMatch', { host: config.host, playerId, score: String(score) });
        const query = `
      INSERT INTO matches (player_id, score, duration_seconds, started_at, finished_at, is_new_record)
      VALUES ($1, $2, $3, NOW() - INTERVAL '1 second' * $3, NOW(), $4)
      RETURNING *;
    `;
        try {
            const result = await executeWrite(query, [playerId, score, durationSeconds, isNewRecord]);
            // Atualizar estatísticas do jogador
            await this.updatePlayerStats(playerId, score, isNewRecord);
            return result.rows[0];
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: recordMatch', { playerId, error: error.message });
            throw error;
        }
    },
    /**
     * Atualiza estatísticas do jogador após partida
     */
    async updatePlayerStats(playerId, score, isNewRecord) {
        const query = `
      UPDATE players SET
        total_games = total_games + 1,
        best_score = CASE WHEN $2 > best_score THEN $2 ELSE best_score END,
        updated_at = NOW()
      WHERE player_id = $1;
    `;
        try {
            await executeWrite(query, [playerId, score]);
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: updatePlayerStats', { playerId, error: error.message });
            throw error;
        }
    },
    // ---- LEITURA (via Réplica de Leitura) ----
    /**
     * Consulta ranking consolidado (réplica de leitura)
     * Aceita pequena defasagem - ideal para relatórios
     */
    async getRankingFromReplica(limit = 10) {
        const config = getReadConfig();
        (0, logger_1.logSafe)('DB Read (replica): getRanking', { host: config.host, limit: String(limit) });
        const query = `
      SELECT 
        ROW_NUMBER() OVER (ORDER BY best_score DESC) as position,
        username,
        best_score,
        total_games
      FROM players
      WHERE best_score > 0
      ORDER BY best_score DESC
      LIMIT $1;
    `;
        try {
            const result = await executeRead(query, [limit]);
            return result.rows;
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: getRankingFromReplica', { error: error.message });
            throw error;
        }
    },
    /**
     * Consulta histórico de partidas do jogador (réplica de leitura)
     */
    async getPlayerHistory(playerId, limit = 20) {
        const config = getReadConfig();
        (0, logger_1.logSafe)('DB Read (replica): getPlayerHistory', { host: config.host, playerId });
        const query = `
      SELECT match_id, player_id, score, duration_seconds, 
             started_at, finished_at, is_new_record
      FROM matches
      WHERE player_id = $1
      ORDER BY finished_at DESC
      LIMIT $2;
    `;
        try {
            const result = await executeRead(query, [playerId, limit]);
            return result.rows;
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: getPlayerHistory', { playerId, error: error.message });
            throw error;
        }
    },
    /**
     * Consulta estatísticas detalhadas do jogador (réplica de leitura)
     */
    async getPlayerStats(playerId) {
        const config = getReadConfig();
        (0, logger_1.logSafe)('DB Read (replica): getPlayerStats', { host: config.host, playerId });
        const query = `
      SELECT 
        p.player_id,
        p.username,
        p.best_score,
        p.total_games,
        p.total_wins,
        p.total_losses,
        COALESCE(AVG(m.score), 0)::INTEGER as average_score,
        COALESCE(SUM(m.duration_seconds), 0)::INTEGER as total_play_time_seconds,
        MAX(m.finished_at) as last_played_at
      FROM players p
      LEFT JOIN matches m ON p.player_id = m.player_id
      WHERE p.player_id = $1
      GROUP BY p.player_id, p.username, p.best_score, 
               p.total_games, p.total_wins, p.total_losses;
    `;
        try {
            const result = await executeRead(query, [playerId]);
            return result.rows[0] || null;
        }
        catch (error) {
            (0, logger_1.logError)('DB Error: getPlayerStats', { playerId, error: error.message });
            throw error;
        }
    },
    /**
     * Verifica conectividade com o banco (escrita)
     */
    async pingWrite() {
        try {
            await executeWrite('SELECT 1 as health;', []);
            return true;
        }
        catch {
            return false;
        }
    },
    /**
     * Verifica conectividade com a réplica (leitura)
     */
    async pingRead() {
        try {
            await executeRead('SELECT 1 as health;', []);
            return true;
        }
        catch {
            return false;
        }
    },
};
// ============================================
// Funções auxiliares de execução de queries
// Em produção, substituir por pg Pool real
// ============================================
async function executeWrite(query, params) {
    const config = getWriteConfig();
    // Importação dinâmica do pg em runtime
    // Em Lambda, instalar 'pg' como dependência
    try {
        const { Pool } = await Promise.resolve().then(() => __importStar(require('pg')));
        const pool = new Pool({
            host: config.host,
            port: config.port,
            database: config.database,
            user: config.user,
            password: config.password,
            ssl: { rejectUnauthorized: false },
            max: 5,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000,
        });
        const result = await pool.query(query, params);
        await pool.end();
        return {
            rows: result.rows,
            rowCount: result.rowCount ?? 0,
        };
    }
    catch (error) {
        (0, logger_1.logError)('executeWrite failed', {
            host: config.host,
            error: error.message
        });
        throw error;
    }
}
async function executeRead(query, params) {
    const config = getReadConfig();
    try {
        const { Pool } = await Promise.resolve().then(() => __importStar(require('pg')));
        const pool = new Pool({
            host: config.host,
            port: config.port,
            database: config.database,
            user: config.user,
            password: config.password,
            ssl: { rejectUnauthorized: false },
            max: 5,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000,
        });
        const result = await pool.query(query, params);
        await pool.end();
        return {
            rows: result.rows,
            rowCount: result.rowCount ?? 0,
        };
    }
    catch (error) {
        (0, logger_1.logError)('executeRead failed', {
            host: config.host,
            error: error.message
        });
        throw error;
    }
}
//# sourceMappingURL=databaseService.js.map