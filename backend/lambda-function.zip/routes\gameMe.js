"use strict";
// GET /game/me - Returns player info and current game session
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameMe = handleGameMe;
const cacheService_1 = require("../services/cacheService");
const response_1 = require("../utils/response");
async function handleGameMe(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    try {
        const playerInfo = await cacheService_1.cacheService.getPlayerInfo(sub);
        const session = await cacheService_1.cacheService.getGameSession(sub);
        return (0, response_1.buildResponse)(200, {
            username: playerInfo?.username || 'Jogador',
            bestScore: playerInfo?.bestScore || 0,
            session: session ? { status: session.status } : null,
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço do jogo temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=gameMe.js.map