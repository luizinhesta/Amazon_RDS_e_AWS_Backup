"use strict";
// GET /ranking/persistent - Ranking consolidado do banco de dados (via réplica)
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleRankingPersistent = handleRankingPersistent;
const databaseService_1 = require("../services/databaseService");
const response_1 = require("../utils/response");
async function handleRankingPersistent(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    try {
        const limit = parseInt(event.queryStringParameters?.limit || '10', 10);
        const safeLimit = Math.min(Math.max(limit, 1), 100);
        const ranking = await databaseService_1.databaseService.getRankingFromReplica(safeLimit);
        return (0, response_1.buildResponse)(200, {
            ranking,
            total: ranking.length,
            source: 'replica',
            description: 'Ranking consolidado do banco de dados (pode ter pequena defasagem)',
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço de banco de dados temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=rankingPersistent.js.map