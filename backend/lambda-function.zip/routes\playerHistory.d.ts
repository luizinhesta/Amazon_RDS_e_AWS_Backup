import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handlePlayerHistory(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=playerHistory.d.ts.map