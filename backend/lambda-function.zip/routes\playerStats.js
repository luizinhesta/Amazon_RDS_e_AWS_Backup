"use strict";
// GET /player/stats - Retorna estatísticas do jogador (via réplica de leitura)
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePlayerStats = handlePlayerStats;
const databaseService_1 = require("../services/databaseService");
const response_1 = require("../utils/response");
async function handlePlayerStats(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    try {
        const stats = await databaseService_1.databaseService.getPlayerStats(sub);
        if (!stats) {
            return (0, response_1.buildResponse)(200, {
                player_id: sub,
                username: 'Jogador',
                best_score: 0,
                total_games: 0,
                total_wins: 0,
                total_losses: 0,
                average_score: 0,
                total_play_time_seconds: 0,
                last_played_at: null,
                source: 'replica',
            }, origin);
        }
        return (0, response_1.buildResponse)(200, {
            ...stats,
            source: 'replica',
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço de banco de dados temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=playerStats.js.map