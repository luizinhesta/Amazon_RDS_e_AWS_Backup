"use strict";
// POST /match/record - Registra partida finalizada no banco permanente (via RDS Proxy)
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleMatchRecord = handleMatchRecord;
const databaseService_1 = require("../services/databaseService");
const response_1 = require("../utils/response");
async function handleMatchRecord(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const sub = event.requestContext?.authorizer?.claims?.sub;
    const username = event.requestContext?.authorizer?.claims?.preferred_username ||
        event.requestContext?.authorizer?.claims?.name || 'Jogador';
    const email = event.requestContext?.authorizer?.claims?.email || '';
    if (!sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não autorizado', origin);
    }
    // Validar body
    let body;
    try {
        body = JSON.parse(event.body || '{}');
    }
    catch {
        return (0, response_1.buildErrorResponse)(400, 'Dados inválidos', origin);
    }
    const score = body.score;
    const durationSeconds = body.durationSeconds;
    const isNewRecord = body.isNewRecord;
    if (typeof score !== 'number' || !Number.isInteger(score) || score < 0 || score >= 1000000) {
        return (0, response_1.buildErrorResponse)(400, 'Pontuação inválida', origin);
    }
    if (typeof durationSeconds !== 'number' || durationSeconds < 0 || durationSeconds > 86400) {
        return (0, response_1.buildErrorResponse)(400, 'Duração inválida', origin);
    }
    if (typeof isNewRecord !== 'boolean') {
        return (0, response_1.buildErrorResponse)(400, 'Campo isNewRecord é obrigatório', origin);
    }
    try {
        // Garantir que o jogador existe no banco
        await databaseService_1.databaseService.upsertPlayer(sub, username, email);
        // Registrar a partida
        const match = await databaseService_1.databaseService.recordMatch(sub, score, Math.floor(durationSeconds), isNewRecord);
        return (0, response_1.buildResponse)(201, {
            recorded: true,
            matchId: match.match_id,
            score: match.score,
            durationSeconds: match.duration_seconds,
            isNewRecord: match.is_new_record,
            source: 'primary',
        }, origin);
    }
    catch {
        return (0, response_1.buildErrorResponse)(503, 'Serviço de banco de dados temporariamente indisponível.', origin);
    }
}
//# sourceMappingURL=matchRecord.js.map